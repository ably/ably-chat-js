export const version = '2.4.1';
export function channelOptionsWithAgent(options) {
    return Object.assign(Object.assign({}, options), { params: Object.assign(Object.assign({}, options === null || options === void 0 ? void 0 : options.params), { agent: `react-hooks/${version}` }) });
}
//# sourceMappingURL=AblyReactHooks.js.map